#ifndef	FS_CRYPTOUSER_H
#define	FS_CRYPTOUSER_H

struct usr{
	uid_t id;
	long long user_key;
	int count;
};

extern struct usr user_keys_array[16];

#endif