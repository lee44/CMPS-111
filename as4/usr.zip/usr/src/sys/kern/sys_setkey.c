#include <sys/sysproto.h>
#include <sys/proc.h>
#include <fs/cryptofs/cryptouser.h>
//required for printf
#include <sys/types.h>
#include <sys/systm.h>

#ifndef _SYS_SYSPROTO_H_

struct getkey_args {
    uid_t id;
};

struct setkey_args {
    unsigned int k0;
    unsigned int k1;
    uid_t id;
};
#endif
/* ARGSUSED */

int sys_getkey(struct thread *td, struct getkey_args *args)
{
    //printf("Working");

    return 0;
}



int sys_setkey(struct thread *td, struct setkey_args *args)
{
	// printf("cr_ruid: %d\n", td->td_ucred->cr_ruid);
	// printf("cr_uid: %d\n", td->td_ucred->cr_uid);
	// printf("cr_svuid: %d\n", td->td_ucred->cr_svuid);

    printf("Key0 is %d\n",args->k0);
    printf("Key1 is %d\n",args->k1);
    printf("UID is %i\n",args->id);

    long long va = (long long) args->k0 << 32 | args->k1;

    struct usr c;
    c.id = args->id;
    c.user_key = va;

    user_keys_array[c.count] = c;
    c.count += c.count % 16; 


    //printf("Working");

    return 0;
}

// int sys_getkey(struct thread *td)
// {

// }