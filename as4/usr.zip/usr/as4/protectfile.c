#include <stdio.h>
#include <fcntl.h>
#include <strings.h>
#include <unistd.h>
#include <stdlib.h>
#include "rijndael.h"
#include <sys/syscall.h>
#include <sys/stat.h>

static char rcsid[] = "$Id: encrypt.c,v 1.2 2003/04/15 01:05:36 elm Exp elm $";

#define KEYBITS 128

int hexvalue (char c)
{
  if (c >= '0' && c <= '9') {
    return (c - '0');
  } else if (c >= 'a' && c <= 'f') {
    return (10 + c - 'a');
  } else if (c >= 'A' && c <= 'F') {
    return (10 + c - 'A');
  } else {
    fprintf (stderr, "ERROR: key digit %c isn't a hex digit!\n", c);
    exit (-1);
  }
}

int main(int argc, char **argv)
{
  unsigned long rk[RKLENGTH(KEYBITS)];	/* round key */
  unsigned char key[KEYLENGTH(KEYBITS)];/* cipher key */
  char	buf[100];
  int i, nbytes, nwritten , ctr;
  int totalbytes;
  unsigned long	k0, k1;
  int fileId;			/* fake (in this example) */
  int nrounds;				// # of Rijndael rounds 
  char *password;			/* supplied (ASCII) password */
  int	fd;
  char *filename, *flag, *inputkey;
  unsigned char filedata[16];
  unsigned char ciphertext[16];
  unsigned char ctrvalue[16];
  struct stat fileStat;
  mode_t mode;
  char key0[9];
  char key1[9];
  int key_0 = 0, key_1 = 0;
  uid_t uid;

  if (argc < 3)
  {
    fprintf (stderr, "Usage: %s -e/-d key file\n", argv[0]);
    return 1;
  }

  flag = argv[1];
  inputkey = argv[2];
  filename = argv[3];

//break up key into two parts
  for (int i = 0; i < 8; i++)
  {
  	key0[i] = hexvalue(inputkey[i]);
  	//printf("Key0 : %i\n",key0[i]);
  	key_0 = 10 * key_0 + (int)(key0[i]);
  	printf("Key_0 : %i\n",key_0);
  	
  }
  //key0[8] = '\0';

  for (int z = 8; z < 16; z++)
  {
  	key1[z-8] = hexvalue(inputkey[z]);
  	//printf("Key1 : %i\n",key1[z-8]);
  	key_1 = 10 * key_1 + (int)(key1[z-8]);
  	printf("Key_1 : %i\n",key_1);

  }
  //key1[8] = '\0';

//load stat
  if(stat(filename,&fileStat) < 0){
	printf(stderr, "Failed to stat file\n");
	return 1;
  }    
  
  // printf("Key_0 : %i\n",key_0);
  // printf("Key_1 : %i\n",key_1);

  syscall(548, (unsigned int)key_0, (unsigned int)key_1, fileStat.st_uid);


//encrypt
  if(flag[0] == '-' && flag[1] == 'e')
  {
  	//check sticky bit
    mode = fileStat.st_mode & 07777;
    if (!(fileStat.st_mode & S_ISTXT))
    {
    	fileId = fileStat.st_ino;

        bzero (key, sizeof (key));
	    k0 = strtol (key0, NULL, 0);
	    k1 = strtol (key1, NULL, 0);
	    bcopy (&k0, &(inputkey[0]), sizeof (k0));
	    bcopy (&k1, &(inputkey[sizeof(k0)]), sizeof (k1));

	    //syscall(548, k0, k1, fileStat.st_uid);

	    /* Print the key, just in case */
	    // for (i = 0; i < sizeof (inputkey); i++) {
	    // 	sprintf (buf+2*i, "%02x", inputkey[sizeof(inputkey)-i-1]);
	    // }
	    // fprintf (stderr, "KEY: %s\n", buf);

	    /*
	    * Initialize the Rijndael algorithm.  The round key is initialized by this
	    * call from the values passed in key and KEYBITS.
	    */
	    nrounds = rijndaelSetupEncrypt(rk, inputkey, KEYBITS);

	    /*
	    * Open the file.
	    */
	    fd = open(filename, O_RDWR);
	    if (fd < 0)
	    {
	     fprintf(stderr, "Error opening file %s\n", argv[2]);
	     return 1;
	    }

	  /* fileID goes into bytes 8-11 of the ctrvalue */
	  bcopy (&fileId, &(ctrvalue[8]), sizeof (fileId));

	  /* This loop reads 16 bytes from the file, XORs it with the encrypted
	     CTR value, and then writes it back to the file at the same position.
	     Note that CTR encryption is nice because the same algorithm does
	     encryption and decryption.  In other words, if you run this program
	     twice, it will first encrypt and then decrypt the file.
	  */
	  for (ctr = 0, totalbytes = 0; /* loop forever */; ctr++)
	  {
	    /* Read 16 bytes (128 bits, the blocksize) from the file */
	    nbytes = read (fd, filedata, sizeof (filedata));
	    if (nbytes <= 0) {
	      break;
	    }
	    if (lseek (fd, totalbytes, SEEK_SET) < 0)
	    {
	      perror ("Unable to seek back over buffer");
	      exit (-1);
	    }

	    /* Set up the CTR value to be encrypted */
	    bcopy (&ctr, &(ctrvalue[0]), sizeof (ctr));

	    /* Call the encryption routine to encrypt the CTR value */
	    rijndaelEncrypt(rk, nrounds, ctrvalue, ciphertext);

	    /* XOR the result into the file data */
	    for (i = 0; i < nbytes; i++) {
	      filedata[i] ^= ciphertext[i];
	    }

	    /* Write the result back to the file */
	    nwritten = write(fd, filedata, nbytes);
	    if (nwritten != nbytes)
	    {
	      fprintf (stderr,
		       "%s: error writing the file (expected %d, got %d at ctr %d\n)",
		       argv[0], nbytes, nwritten, ctr);
	      break;
	    }

	    /* Increment the total bytes written */
	    totalbytes += nbytes;
	  }
	   close (fd);

       mode |= S_ISTXT;
       chmod (filename, mode);
    }
  }
  

  if(flag[0] == '-' && flag[1] == 'd')
  {
  	if(stat(filename,&fileStat) < 0)    
        return 1;

    mode = fileStat.st_mode & 07777;
    if (!(fileStat.st_mode & S_ISTXT))
    {
    	fileId = fileStat.st_ino;
        mode &= ~S_ISTXT;
        chmod (filename, mode);

        bzero (inputkey, sizeof (key));
	    k0 = strtol (key0, NULL, 0);
	    k1 = strtol (key1, NULL, 0);
	    bcopy (&k0, &(inputkey[0]), sizeof (k0));
	    bcopy (&k1, &(inputkey[sizeof(k0)]), sizeof (k1));

	    /* Print the key, just in case */
	    for (i = 0; i < sizeof (inputkey); i++) {
	    	sprintf (buf+2*i, "%02x", inputkey[sizeof(inputkey)-i-1]);
	    }
	    fprintf (stderr, "KEY: %s\n", buf);

	    /*
	    * Initialize the Rijndael algorithm.  The round key is initialized by this
	    * call from the values passed in key and KEYBITS.
	    */
	    nrounds = rijndaelSetupEncrypt(rk, inputkey, KEYBITS);

	    /*
	    * Open the file.
	    */
	    fd = open(filename, O_RDWR);
	    if (fd < 0)
	    {
	     fprintf(stderr, "Error opening file %s\n", argv[2]);
	     return 1;
	    }

	  /* fileID goes into bytes 8-11 of the ctrvalue */
	  bcopy (&fileId, &(ctrvalue[8]), sizeof (fileId));

	  /* This loop reads 16 bytes from the file, XORs it with the encrypted
	     CTR value, and then writes it back to the file at the same position.
	     Note that CTR encryption is nice because the same algorithm does
	     encryption and decryption.  In other words, if you run this program
	     twice, it will first encrypt and then decrypt the file.
	  */
	  for (ctr = 0, totalbytes = 0; /* loop forever */; ctr++)
	  {
	    /* Read 16 bytes (128 bits, the blocksize) from the file */
	    nbytes = read (fd, filedata, sizeof (filedata));
	    if (nbytes <= 0) {
	      break;
	    }
	    if (lseek (fd, totalbytes, SEEK_SET) < 0)
	    {
	      perror ("Unable to seek back over buffer");
	      exit (-1);
	    }

	    /* Set up the CTR value to be encrypted */
	    bcopy (&ctr, &(ctrvalue[0]), sizeof (ctr));

	    /* Call the encryption routine to encrypt the CTR value */
	    rijndaelEncrypt(rk, nrounds, ctrvalue, ciphertext);

	    /* XOR the result into the file data */
	    for (i = 0; i < nbytes; i++) {
	      filedata[i] ^= ciphertext[i];
	    }

	    /* Write the result back to the file */
	    nwritten = write(fd, filedata, nbytes);
	    if (nwritten != nbytes)
	    {
	      fprintf (stderr,
		       "%s: error writing the file (expected %d, got %d at ctr %d\n)",
		       argv[0], nbytes, nwritten, ctr);
	      break;
	    }

	    /* Increment the total bytes written */
	    totalbytes += nbytes;
	  }
	   close (fd);
    }
  }

}
